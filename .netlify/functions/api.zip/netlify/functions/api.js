var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_pg = __toESM(require("pg"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
const { Client } = import_pg.default;
const DB_URL_FALLBACK = "postgresql://neondb_owner:npg_MN89fGchBILz@ep-crimson-river-atoix06e-pooler.c-9.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require";
const JWT_SECRET = process.env.JWT_SECRET || "super-secret-s3-sentinel-key-2026";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
};
async function getDbClient() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL || DB_URL_FALLBACK,
    ssl: {
      rejectUnauthorized: false
    }
  });
  await client.connect();
  return client;
}
function authenticate(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new Error("Unauthorized: Missing or invalid token format");
  }
  const token = authHeader.split(" ")[1];
  try {
    return import_jsonwebtoken.default.verify(token, JWT_SECRET);
  } catch (err) {
    throw new Error("Unauthorized: Invalid or expired token");
  }
}
const handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }
  const path = event.path.replace(/^\/\.netlify\/functions\/api/, "/api");
  const method = event.httpMethod;
  if (path === "/api/debug" && method === "GET") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        hasDatabaseUrl: !!process.env.DATABASE_URL,
        databaseUrlPrefix: process.env.DATABASE_URL ? process.env.DATABASE_URL.substring(0, 25) : null,
        nodeEnv: process.env.NODE_ENV,
        envKeys: Object.keys(process.env).filter((k) => k.includes("DATA") || k.includes("JWT") || k.includes("NETLIFY"))
      })
    };
  }
  let client;
  try {
    client = await getDbClient();
    if (path === "/api/auth/register" && method === "POST") {
      const { name, email, password, role } = JSON.parse(event.body);
      if (!name || !email || !password) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Name, email, and password are required" })
        };
      }
      const salt = await import_bcryptjs.default.genSalt(10);
      const passwordHash = await import_bcryptjs.default.hash(password, salt);
      const userRole = role === "admin" ? "admin" : "murid";
      const res = await client.query(
        "INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id, name, email, role",
        [name, email, passwordHash, userRole]
      );
      return {
        statusCode: 201,
        headers: corsHeaders,
        body: JSON.stringify(res.rows[0])
      };
    }
    if (path === "/api/auth/login" && method === "POST") {
      const { email, password } = JSON.parse(event.body);
      if (!email || !password) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Email and password are required" })
        };
      }
      const res = await client.query("SELECT * FROM users WHERE email = $1", [email]);
      if (res.rows.length === 0) {
        return {
          statusCode: 401,
          headers: corsHeaders,
          body: JSON.stringify({ error: "User not found" })
        };
      }
      const user2 = res.rows[0];
      const valid = await import_bcryptjs.default.compare(password, user2.password_hash);
      if (!valid) {
        return {
          statusCode: 401,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Incorrect password" })
        };
      }
      const token = import_jsonwebtoken.default.sign(
        { id: user2.id, email: user2.email, role: user2.role, name: user2.name },
        JWT_SECRET,
        { expiresIn: "1d" }
      );
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          token,
          user: { id: user2.id, name: user2.name, email: user2.email, role: user2.role }
        })
      };
    }
    const user = authenticate(event);
    if (path === "/api/subjects") {
      if (method === "GET") {
        const query = user.role === "admin" ? "SELECT * FROM subjects ORDER BY id ASC" : "SELECT * FROM subjects WHERE is_active = true ORDER BY id ASC";
        const res = await client.query(query);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        if (user.role !== "admin") throw new Error("Forbidden");
        const { name, description, icon, is_active } = JSON.parse(event.body);
        const res = await client.query(
          "INSERT INTO subjects (name, description, icon, is_active) VALUES ($1, $2, $3, $4) RETURNING *",
          [name, description, icon, is_active !== false]
        );
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path.startsWith("/api/subjects/") && user.role === "admin") {
      const id = path.split("/").pop();
      if (method === "PUT") {
        const { name, description, icon, is_active } = JSON.parse(event.body);
        const res = await client.query(
          "UPDATE subjects SET name = $1, description = $2, icon = $3, is_active = $4 WHERE id = $5 RETURNING *",
          [name, description, icon, is_active, id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
      if (method === "DELETE") {
        await client.query("DELETE FROM subjects WHERE id = $1", [id]);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };
      }
    }
    if (path === "/api/chapters") {
      if (method === "GET") {
        const subject_id = event.queryStringParameters.subject_id;
        const res = await client.query(
          "SELECT * FROM chapters WHERE subject_id = $1 ORDER BY order_number ASC",
          [subject_id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        if (user.role !== "admin") throw new Error("Forbidden");
        const { subject_id, title, order_number } = JSON.parse(event.body);
        const res = await client.query(
          "INSERT INTO chapters (subject_id, title, order_number) VALUES ($1, $2, $3) RETURNING *",
          [subject_id, title, order_number]
        );
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path.startsWith("/api/chapters/") && user.role === "admin") {
      const id = path.split("/").pop();
      if (method === "PUT") {
        const { title, order_number } = JSON.parse(event.body);
        const res = await client.query(
          "UPDATE chapters SET title = $1, order_number = $2 WHERE id = $3 RETURNING *",
          [title, order_number, id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
      if (method === "DELETE") {
        await client.query("DELETE FROM chapters WHERE id = $1", [id]);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };
      }
    }
    if (path === "/api/theories") {
      if (method === "GET") {
        const chapter_id = event.queryStringParameters.chapter_id;
        const res = await client.query(
          "SELECT * FROM theories WHERE chapter_id = $1 ORDER BY id ASC",
          [chapter_id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        if (user.role !== "admin") throw new Error("Forbidden");
        const { chapter_id, title, content } = JSON.parse(event.body);
        const check = await client.query("SELECT * FROM theories WHERE chapter_id = $1", [chapter_id]);
        let res;
        if (check.rows.length > 0) {
          res = await client.query(
            "UPDATE theories SET title = $1, content = $2 WHERE chapter_id = $3 RETURNING *",
            [title, content, chapter_id]
          );
        } else {
          res = await client.query(
            "INSERT INTO theories (chapter_id, title, content) VALUES ($1, $2, $3) RETURNING *",
            [chapter_id, title, content]
          );
        }
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path === "/api/exercises") {
      if (method === "GET") {
        const chapter_id = event.queryStringParameters.chapter_id;
        const res = await client.query(
          "SELECT * FROM exercises WHERE chapter_id = $1 ORDER BY id ASC",
          [chapter_id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        if (user.role !== "admin") throw new Error("Forbidden");
        const { chapter_id, title } = JSON.parse(event.body);
        const res = await client.query(
          "INSERT INTO exercises (chapter_id, title) VALUES ($1, $2) RETURNING *",
          [chapter_id, title]
        );
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path === "/api/questions") {
      if (method === "GET") {
        const exercise_id = event.queryStringParameters.exercise_id;
        const result_id = event.queryStringParameters.result_id;
        if (result_id) {
          const resultRes = await client.query("SELECT answers FROM student_results WHERE id = $1", [result_id]);
          const resultRow = resultRes.rows[0];
          if (resultRow) {
            const parsed = typeof resultRow.answers === "string" ? JSON.parse(resultRow.answers) : resultRow.answers;
            if (parsed && parsed.questions) {
              return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify(parsed.questions)
              };
            }
          }
          const res2 = await client.query(
            "SELECT * FROM questions WHERE exercise_id = $1 ORDER BY id ASC",
            [exercise_id]
          );
          return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(res2.rows)
          };
        }
        const infoRes = await client.query(`
          SELECT s.name as subject_name, c.title as chapter_title, c.subject_id
          FROM exercises e
          JOIN chapters c ON e.chapter_id = c.id
          JOIN subjects s ON c.subject_id = s.id
          WHERE e.id = $1
        `, [exercise_id]);
        const info = infoRes.rows[0];
        if (info && info.subject_name === "Hafalan Perkalian 1-10") {
          const match = /Perkalian\s+(\d+)/i.exec(info.chapter_title);
          const base = match ? parseInt(match[1], 10) : 1;
          const multipliers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
          for (let i = multipliers.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = multipliers[i];
            multipliers[i] = multipliers[j];
            multipliers[j] = temp;
          }
          const questions = multipliers.map((y, index) => {
            const correctAnswer = base * y;
            const distractors = /* @__PURE__ */ new Set();
            distractors.add(base * (y + 1));
            if (y > 1) distractors.add(base * (y - 1));
            distractors.add(base * y + base);
            distractors.add(base * y - base);
            const offsets = [-2, 2, -1, 1, -5, 5, -3, 3, -4, 4];
            for (const offset of offsets) {
              if (distractors.size >= 3) break;
              const val = correctAnswer + offset;
              if (val > 0 && val !== correctAnswer) {
                distractors.add(val);
              }
            }
            while (distractors.size < 3) {
              const val = Math.max(1, correctAnswer + Math.floor(Math.random() * 11) - 5);
              if (val !== correctAnswer) {
                distractors.add(val);
              }
            }
            const incorrectList = Array.from(distractors).slice(0, 3);
            const options = [correctAnswer.toString(), ...incorrectList.map((v) => v.toString())];
            for (let i = options.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              const tempOpt = options[i];
              options[i] = options[j];
              options[j] = tempOpt;
            }
            return {
              id: index + 1,
              // temporary identifier
              exercise_id: parseInt(exercise_id, 10),
              question_text: `Berapakah hasil dari ${base} x ${y}?`,
              options,
              correct_answer: correctAnswer.toString(),
              subject_id: info.subject_id
            };
          });
          return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(questions)
          };
        }
        const res = await client.query(
          "SELECT * FROM questions WHERE exercise_id = $1 ORDER BY id ASC",
          [exercise_id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        if (user.role !== "admin") throw new Error("Forbidden");
        const { exercise_id, question_text, options, correct_answer } = JSON.parse(event.body);
        const res = await client.query(
          "INSERT INTO questions (exercise_id, question_text, options, correct_answer) VALUES ($1, $2, $3, $4) RETURNING *",
          [exercise_id, question_text, JSON.stringify(options), correct_answer]
        );
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path.startsWith("/api/questions/") && user.role === "admin") {
      const id = path.split("/").pop();
      if (method === "PUT") {
        const { question_text, options, correct_answer } = JSON.parse(event.body);
        const res = await client.query(
          "UPDATE questions SET question_text = $1, options = $2, correct_answer = $3 WHERE id = $4 RETURNING *",
          [question_text, JSON.stringify(options), correct_answer, id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
      if (method === "DELETE") {
        await client.query("DELETE FROM questions WHERE id = $1", [id]);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };
      }
    }
    if (path === "/api/results") {
      if (method === "POST") {
        const { exercise_id, answers, questions: clientQuestions } = JSON.parse(event.body);
        let questions;
        if (clientQuestions && clientQuestions.length > 0) {
          questions = clientQuestions;
        } else {
          const questionsRes = await client.query("SELECT * FROM questions WHERE exercise_id = $1", [exercise_id]);
          questions = questionsRes.rows;
        }
        let correctCount = 0;
        questions.forEach((q) => {
          if (answers[q.id] === q.correct_answer) {
            correctCount++;
          }
        });
        const total = questions.length;
        const score = total > 0 ? Math.round(correctCount / total * 100) : 0;
        const payloadToStore = {
          answers,
          questions
        };
        const insertRes = await client.query(
          "INSERT INTO student_results (user_id, exercise_id, score, answers, started_at, completed_at) VALUES ($1, $2, $3, $4, NOW(), NOW()) RETURNING *",
          [user.id, exercise_id, score, JSON.stringify(payloadToStore)]
        );
        const infoRes = await client.query(`
          SELECT c.subject_id FROM exercises e
          JOIN chapters c ON e.chapter_id = c.id
          WHERE e.id = $1
        `, [exercise_id]);
        const subjectId = infoRes.rows[0]?.subject_id;
        const earnedBadges = [];
        if (subjectId) {
          const badgesRes = await client.query(
            "SELECT * FROM badges WHERE subject_id = $1 AND is_active = true",
            [subjectId]
          );
          for (const badge of badgesRes.rows) {
            let qualify = false;
            const hasBadge = await client.query(
              "SELECT 1 FROM student_badges WHERE user_id = $1 AND badge_id = $2",
              [user.id, badge.id]
            );
            if (hasBadge.rows.length === 0) {
              if (badge.condition_type === "perfect_score" && score === 100) {
                qualify = true;
              } else if (badge.condition_type === "complete_exercise") {
                qualify = true;
              }
              if (qualify) {
                await client.query(
                  "INSERT INTO student_badges (user_id, badge_id) VALUES ($1, $2)",
                  [user.id, badge.id]
                );
                earnedBadges.push(badge);
              }
            }
          }
        }
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            result: insertRes.rows[0],
            score,
            correctCount,
            total,
            earnedBadges
          })
        };
      }
      if (method === "GET") {
        let query;
        let params = [];
        if (user.role === "admin") {
          query = `
            SELECT r.*, u.name as student_name, e.title as exercise_title, s.name as subject_name, c.subject_id as subject_id 
            FROM student_results r
            JOIN users u ON r.user_id = u.id
            JOIN exercises e ON r.exercise_id = e.id
            JOIN chapters c ON e.chapter_id = c.id
            JOIN subjects s ON c.subject_id = s.id
            ORDER BY r.completed_at DESC
          `;
        } else {
          query = `
            SELECT r.*, e.title as exercise_title, s.name as subject_name, c.subject_id as subject_id 
            FROM student_results r
            JOIN exercises e ON r.exercise_id = e.id
            JOIN chapters c ON e.chapter_id = c.id
            JOIN subjects s ON c.subject_id = s.id
            WHERE r.user_id = $1
            ORDER BY r.completed_at DESC
          `;
          params = [user.id];
        }
        const res = await client.query(query, params);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
    }
    if (path === "/api/badges" && method === "GET") {
      const res = await client.query(`
        SELECT sb.*, b.name, b.icon, b.condition_type, b.condition_value, s.name as subject_name
        FROM student_badges sb
        JOIN badges b ON sb.badge_id = b.id
        JOIN subjects s ON b.subject_id = s.id
        WHERE sb.user_id = $1
        ORDER BY sb.earned_at DESC
      `, [user.id]);
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(res.rows)
      };
    }
    if (path === "/api/admin/badges") {
      if (user.role !== "admin") throw new Error("Forbidden");
      if (method === "GET") {
        const res = await client.query(`
          SELECT b.*, s.name as subject_name
          FROM badges b
          JOIN subjects s ON b.subject_id = s.id
          ORDER BY b.id ASC
        `);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows)
        };
      }
      if (method === "POST") {
        const { name, icon, condition_type, condition_value, subject_id, is_active } = JSON.parse(event.body);
        const res = await client.query(
          "INSERT INTO badges (name, icon, condition_type, condition_value, subject_id, is_active) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
          [name, icon, condition_type, condition_value, subject_id, is_active !== false]
        );
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
    }
    if (path.startsWith("/api/admin/badges/") && user.role === "admin") {
      const id = path.split("/").pop();
      if (method === "PUT") {
        const { name, icon, condition_type, condition_value, is_active } = JSON.parse(event.body);
        const res = await client.query(
          "UPDATE badges SET name = $1, icon = $2, condition_type = $3, condition_value = $4, is_active = $5 WHERE id = $6 RETURNING *",
          [name, icon, condition_type, condition_value, is_active, id]
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(res.rows[0])
        };
      }
      if (method === "DELETE") {
        await client.query("DELETE FROM badges WHERE id = $1", [id]);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({ success: true })
        };
      }
    }
    if (path === "/api/admin/stats" && method === "GET") {
      if (user.role !== "admin") throw new Error("Forbidden");
      const totalStudentsRes = await client.query("SELECT COUNT(*) FROM users WHERE role = 'murid'");
      const totalSubjectsRes = await client.query("SELECT COUNT(*) FROM subjects");
      const totalResultsRes = await client.query("SELECT COUNT(*) FROM student_results");
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          totalStudents: parseInt(totalStudentsRes.rows[0].count, 10),
          totalSubjects: parseInt(totalSubjectsRes.rows[0].count, 10),
          totalExercisesCompleted: parseInt(totalResultsRes.rows[0].count, 10)
        })
      };
    }
    return {
      statusCode: 404,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Endpoint not found" })
    };
  } catch (err) {
    console.error("Error handling API request:", err);
    return {
      statusCode: err.message.startsWith("Unauthorized") ? 401 : err.message.startsWith("Forbidden") ? 403 : 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: err.message || "Internal Server Error" })
    };
  } finally {
    if (client) {
      await client.end();
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
